"""下册实验四：衍射光栅及其特性，按表 4-1 和三项数据处理要求。"""

import hashlib
import io
import math
import re

import matplotlib.font_manager as fm
import matplotlib as mpl
from matplotlib.backends.backend_agg import FigureCanvasAgg
from matplotlib.figure import Figure
import numpy as np
import pandas as pd
import streamlit as st

ORDER = '级次 k'
SPECTRAL = '谱线'
WAVE = 'λ / nm'
ANGLES = ('θ左Ⅰ', 'θ左Ⅱ', 'θ右Ⅰ', 'θ右Ⅱ')
PHI_I, PHI_II, PHI = 'φⅠ / °', 'φⅡ / °', 'φ / °'
SPACING = 'dᵢ / nm'
COLORS = ('蓝', '绿', '黄1', '黄2')
WAVELENGTHS = (435.8, 546.1, 577.0, 579.0)


def parse_angle(value):
    """度.分沿用项目分光计习惯，也支持明确的度分符号或冒号。"""
    if pd.isna(value) or str(value).strip() == '':
        return math.nan
    match = re.fullmatch(r'(\d{1,3})(?:([.:°度])\s*(\d{1,2})[′\'分]?)?', str(value).strip())
    if not match:
        raise ValueError('角位置请填度.分、度:分或度°分′，例如 30.15、30:15、30°15′。')
    degrees, minute_text = int(match[1]), match[3] or '0'
    minutes = int(minute_text)
    if match[2] == '.' and len(minute_text) == 1:
        minutes *= 10
    if minutes >= 60 or degrees > 360 or (degrees == 360 and minutes != 0):
        raise ValueError('角位置须在 0° 至 360° 之间，分数须小于 60。')
    return (degrees + minutes / 60) % 360


def diffraction_angle(left, right):
    """圆周上的最短角距离除以二，避免跨 0° 时误取整圈差值。"""
    if not math.isfinite(left) or not math.isfinite(right):
        return math.nan
    difference = abs(right - left)
    return min(difference, 360 - difference) / 2


def angle_text(value):
    """分钟读数求半角及双游标平均可产生 30″、15″，只显示实际产生的位。"""
    if not math.isfinite(value):
        return '—'
    degrees, remainder = divmod(round(value * 3600), 3600)
    minutes, seconds = divmod(remainder, 60)
    text = rf'{degrees}^{{\circ}}{minutes:02d}^{{\prime}}'
    if seconds:
        text += rf'{seconds:02d}^{{\prime\prime}}'
    return text


def number_text(value, digits=4):
    if value is None or not math.isfinite(value):
        return '—'
    text = f'{value:#.{digits}g}'
    if 'e' in text:
        mantissa, exponent = text.split('e')
        return rf'{mantissa}\times10^{{{int(exponent)}}}'
    return text


def interval_dispersion(phi_a, phi_b, lambda_a, lambda_b, order, spacing):
    """Δφ/Δλ：角差转为 rad，理论值在区间中点角处计算。"""
    result = dict(delta_phi=math.nan, measured=math.nan, theoretical=math.nan, approximate=math.nan)
    if math.isfinite(phi_a) and math.isfinite(phi_b):
        delta_phi = math.radians(phi_b - phi_a)
        result.update(delta_phi=delta_phi, measured=delta_phi / (lambda_b - lambda_a))
        midpoint = math.radians((phi_a + phi_b) / 2)
        if math.isfinite(spacing) and spacing > 0 and math.cos(midpoint) > 1e-12:
            result['theoretical'] = order / (spacing * math.cos(midpoint))
    if math.isfinite(spacing) and spacing > 0:
        result['approximate'] = order / spacing
    return result


class Experiment:
    volume = '下册'
    number = 4
    experiment_id = 'lower_04_diffraction_grating'
    plot_has_downloads = True

    def __init__(self):
        self.name = '实验四：衍射光栅及其特性'
        self.description = r"""
##### 数据说明
- 表 4-1：记录零级位置及一、二级蓝、绿、黄1、黄2谱线的左右角位置，分别读取游标Ⅰ、Ⅱ。
- 已知波长依次为 435.8、546.1、577.0、579.0 nm；表头记录照亮光栅的长度 $l$（mm）和光栅编号。
- 角位置按度、分填写：30.15 表示 30°15′，也可填写 30:15 或 30°15′；30.10 表示 30°10′。
- 注意测量结果及其不确定度的有效位数。
"""
        self.input_key = '表 4-1：测量光栅常数'
        self.length_mm, self.grating_number = None, ''
        self.initial_df = {self.input_key: pd.DataFrame({
            ORDER: [0, *([1] * 4), *([2] * 4)],
            SPECTRAL: ['0级', *COLORS, *COLORS],
            WAVE: [math.nan, *WAVELENGTHS, *WAVELENGTHS],
            **{column: [None] * 9 for column in ANGLES},
        })}
        self.static_col = {self.input_key: [ORDER, SPECTRAL, WAVE]}
        self.editor_source = self.initial_df[self.input_key].copy()
        self.editor_version, self.upload_digest = 0, None
        self.final_df = {}
        self.mean_spacing, self.slit_count = math.nan, math.nan
        self.spacing_count = 0
        self.dispersion = pd.DataFrame()
        self.input_issues = []

    def set_initial_df(self, frame, key):
        if key != self.input_key:
            raise KeyError(key)
        if list(frame.columns) != list(self.initial_df[key].columns) or len(frame) != 9:
            raise ValueError('CSV 须保留表 4-1 的 9 行、列名及列顺序。')
        frame = frame.reset_index(drop=True).copy()
        if list(pd.to_numeric(frame[ORDER], errors='raise')) != [0, *([1] * 4), *([2] * 4)]:
            raise ValueError('级次须依次为 0、一级四行、二级四行。')
        frame[ORDER] = [0, *([1] * 4), *([2] * 4)]
        if list(frame[SPECTRAL]) != ['0级', *COLORS, *COLORS]:
            raise ValueError('谱线顺序须为 0级，以及各级的蓝、绿、黄1、黄2。')
        wave = pd.to_numeric(frame[WAVE], errors='raise').to_numpy(dtype=float)
        if not np.array_equal(wave, [math.nan, *WAVELENGTHS, *WAVELENGTHS], equal_nan=True):
            raise ValueError('波长须保留书中的 435.8、546.1、577.0、579.0 nm。')
        frame[WAVE] = wave
        for column in ANGLES:
            for value in frame[column]:
                parse_angle(value)
            frame[column] = frame[column].map(
                lambda value: None if pd.isna(value) or str(value).strip() == '' else str(value).strip()
            )
        self.initial_df[key] = frame

    def render_inputs(self):
        length_key, number_key = f'{self.experiment_id}_length', f'{self.experiment_id}_number'
        st.session_state.setdefault(length_key, self.length_mm)
        st.session_state.setdefault(number_key, self.grating_number)
        self.length_mm = st.number_input(
            '照亮光栅的长度 l / mm', min_value=1e-6, value=None, format='%g',
            placeholder='填写表头 l', key=length_key,
        )
        self.grating_number = st.text_input('光栅编号', key=number_key)
        uploaded = st.file_uploader(
            '上传 CSV 文件', type='csv', key=f'{self.experiment_id}_upload',
            help='角位置列按文本读取，保留度.分写法；格式与下载的输入表一致。',
        )
        if uploaded is None:
            self.upload_digest = None
        else:
            digest = hashlib.sha256(uploaded.getvalue()).hexdigest()
            if digest != self.upload_digest:
                try:
                    frame = pd.read_csv(uploaded, dtype={column: 'string' for column in ANGLES})
                    self.set_initial_df(frame.drop(columns='Unnamed: 0', errors='ignore'), self.input_key)
                    self.editor_source = self.initial_df[self.input_key].copy()
                    self.editor_version += 1
                    self.upload_digest = digest
                except (ValueError, KeyError, pd.errors.ParserError) as error:
                    st.error(f'CSV 导入失败：{error}')
        editor_key = f'{self.experiment_id}_editor_{self.editor_version}'
        if editor_key not in st.session_state:
            self.editor_source = self.initial_df[self.input_key].copy()
        st.markdown('**表 4-1：角位置原始记录**')
        edited = st.data_editor(
            self.editor_source, hide_index=True, height='auto', key=editor_key,
            disabled=self.static_col[self.input_key],
            column_config={
                WAVE: st.column_config.NumberColumn(format='%.1f'),
                **{column: st.column_config.TextColumn(
                    help='度.分，例如 30.15；也支持 30°15′ 和 30:15。'
                ) for column in ANGLES},
            },
        )
        try:
            self.set_initial_df(edited, self.input_key)
        except ValueError as error:
            st.error(str(error))
        st.caption('零级只记录角位置；光栅常数由一、二级谱线计算。')
        st.download_button(
            '下载输入 CSV', self.initial_df[self.input_key].to_csv(index=False),
            file_name='下册_实验四_衍射光栅_表4-1输入.csv', mime='text/csv',
            key=f'{self.experiment_id}_input_download',
        )

    def fill_data(self):
        frame = self.initial_df[self.input_key].copy()
        for column in (PHI_I, PHI_II, PHI, SPACING):
            frame[column] = math.nan
        self.input_issues = []
        for row in range(1, 9):
            angles = [parse_angle(frame.at[row, column]) for column in ANGLES]
            phi_i, phi_ii = diffraction_angle(angles[0], angles[2]), diffraction_angle(angles[1], angles[3])
            frame.at[row, PHI_I], frame.at[row, PHI_II] = phi_i, phi_ii
            if math.isfinite(phi_i) and math.isfinite(phi_ii):
                phi = (phi_i + phi_ii) / 2
                frame.at[row, PHI] = phi
                if phi > 0:
                    frame.at[row, SPACING] = frame.at[row, ORDER] * frame.at[row, WAVE] / math.sin(math.radians(phi))
                else:
                    self.input_issues.append(f'{frame.at[row, ORDER]}级{frame.at[row, SPECTRAL]}：衍射角为零，不能计算光栅常数。')
        spacings = frame[SPACING].dropna()
        self.spacing_count = len(spacings)
        self.mean_spacing = float(spacings.mean()) if len(spacings) else math.nan
        if self.length_mm is not None and (not math.isfinite(float(self.length_mm)) or self.length_mm <= 0):
            raise ValueError('照亮光栅的长度 l 必须为正的有限数值。')
        self.slit_count = (self.length_mm * 1e6 / self.mean_spacing
                           if self.length_mm is not None and math.isfinite(self.mean_spacing) else math.nan)
        records = []
        for order in (1, 2):
            group = frame.loc[frame[ORDER] == order].reset_index(drop=True)
            for interval in range(3):
                first, last = group.iloc[interval], group.iloc[interval + 1]
                result = interval_dispersion(
                    first[PHI], last[PHI], first[WAVE], last[WAVE], order, self.mean_spacing,
                )
                records.append({
                    ORDER: order, '谱线区间': f'{first[SPECTRAL]}—{last[SPECTRAL]}',
                    'Δλ / nm': last[WAVE] - first[WAVE],
                    'Δφ / rad': result['delta_phi'],
                    'ψ实 / (rad/nm)': result['measured'],
                    'ψ理 / (rad/nm)': result['theoretical'],
                    'k/d̄ / (rad/nm)': result['approximate'],
                })
        self.dispersion = pd.DataFrame(records)
        self.final_df = {self.input_key: frame}

    def render_results(self):
        frame = self.final_df[self.input_key]
        display = frame.copy()
        for column in ANGLES:
            display[column] = frame[column].map(
                lambda value: '—' if not math.isfinite(parse_angle(value)) else '$' + angle_text(parse_angle(value)) + '$'
            )
        display[WAVE] = frame[WAVE].map(lambda value: f'{value:.1f}' if pd.notna(value) else '—')
        for column in (PHI_I, PHI_II, PHI):
            display[column] = frame[column].map(lambda value: '$' + angle_text(value) + '$' if math.isfinite(value) else '—')
        display[SPACING] = frame[SPACING].map(lambda value: '$' + number_text(value) + '$' if math.isfinite(value) else '—')
        headers = {
            WAVE: r'$\lambda/\mathrm{nm}$',
            ANGLES[0]: r'$\theta_{\text{左},\mathrm{I}}$',
            ANGLES[1]: r'$\theta_{\text{左},\mathrm{II}}$',
            ANGLES[2]: r'$\theta_{\text{右},\mathrm{I}}$',
            ANGLES[3]: r'$\theta_{\text{右},\mathrm{II}}$',
            PHI_I: r'$\varphi_{\mathrm{I}}$', PHI_II: r'$\varphi_{\mathrm{II}}$',
            PHI: r'$\varphi=(\varphi_{\mathrm{I}}+\varphi_{\mathrm{II}})/2$',
            SPACING: r'$d_i/\mathrm{nm}$',
        }
        st.markdown('**表 4-1：测量光栅常数**')
        length = '未填写' if self.length_mm is None else f'{self.length_mm:g} mm'
        st.write(f'l = {length}；光栅编号：{self.grating_number or "未填写"}')
        st.table(display.rename(columns=headers), hide_index=True)
        for message in self.input_issues:
            st.warning(message)
        st.download_button(
            '下载结果 CSV', frame.to_csv(index=False), file_name='下册_实验四_衍射光栅_表4-1结果.csv',
            mime='text/csv', key=f'{self.experiment_id}_result_download',
        )

    def calculate(self):
        frame = self.final_df[self.input_key]
        st.markdown('**1. 计算光栅常数**')
        st.latex(r'\varphi_{\mathrm{I,II}}=\frac{|\theta_{\text{右},\mathrm{I,II}}-\theta_{\text{左},\mathrm{I,II}}|}{2},\qquad'
                 r'\varphi=\frac{\varphi_{\mathrm{I}}+\varphi_{\mathrm{II}}}{2}')
        st.caption('左右读数跨过 0° 时，角差按圆周上的最短距离计算。')
        st.latex(r'd_i\sin\varphi_i=k_i\lambda_i,\qquad d_i=\frac{k_i\lambda_i}{\sin\varphi_i},\qquad'
                 r'\overline d=\frac{1}{n}\sum_{i=1}^{n}d_i')
        valid = frame.loc[frame[SPACING].notna()]
        for _, row in valid.iterrows():
            st.write(f'{int(row[ORDER])}级 · {row[SPECTRAL]}')
            st.latex(rf'd_i=\frac{{{int(row[ORDER])}\times{row[WAVE]:.1f}}}{{\sin({angle_text(row[PHI])})}}'
                     rf'\approx{number_text(row[SPACING])}\,\mathrm{{nm}}')
        if self.spacing_count:
            terms = '+'.join(number_text(value, digits=6) for value in valid[SPACING])
            st.latex(rf'\overline d=\frac{{{terms}}}{{{self.spacing_count}}}\approx{number_text(self.mean_spacing)}\,\mathrm{{nm}}')
            if self.spacing_count < 8:
                st.caption(f'已完成 {self.spacing_count}/8 条非零级谱线；当前平均值仅使用已完成记录。')
        else:
            st.write('填写一、二级谱线的四个角位置后计算光栅常数；零级不参加平均。')

        st.markdown('**2. 色散曲线、角色散率和光谱特点**')
        st.write('在同一张图中绘制 k=1、k=2 的 φ–λ 曲线，图见下方“绘图”。')
        st.latex(r'\psi_{\text{实}}=\frac{\Delta\varphi}{\Delta\lambda},\qquad'
                 r'\psi_{\text{理}}=\frac{k}{\overline d\cos\varphi}\approx\frac{k}{\overline d}')
        st.caption('按曲线上相邻测量点计算 Δφ/Δλ，角差换算为 rad；ψ理取该区间的中点角。')
        display = self.dispersion.copy()
        for column in display.columns[2:]:
            display[column] = self.dispersion[column].map(
                lambda value: '$' + number_text(value, digits=3) + '$' if math.isfinite(value) else '—'
            )
        st.table(display, hide_index=True)
        for order in (1, 2):
            group = frame.loc[frame[ORDER] == order].reset_index(drop=True)
            for interval in range(3):
                record = self.dispersion.loc[
                    (self.dispersion[ORDER] == order) &
                    (self.dispersion['谱线区间'] == f'{COLORS[interval]}—{COLORS[interval + 1]}')
                ].iloc[0]
                if math.isfinite(record['ψ实 / (rad/nm)']):
                    first, last = group.iloc[interval], group.iloc[interval + 1]
                    st.write(f'{order}级 · {record["谱线区间"]}')
                    st.latex(rf'\psi_{{\text{{实}},{order}}}=\frac{{'
                             rf'({last[PHI]:.6g}-{first[PHI]:.6g})\times\pi/180'
                             rf'}}{{{last[WAVE]:.1f}-{first[WAVE]:.1f}}}'
                             rf'\approx{number_text(record["ψ实 / (rad/nm)"], digits=3)}\,\mathrm{{rad/nm}}')
                    if math.isfinite(record['ψ理 / (rad/nm)']):
                        midpoint = (first[PHI] + last[PHI]) / 2
                        st.latex(rf'\psi_{{\text{{理}},{order}}}=\frac{{{order}}}{{'
                                 rf'{number_text(self.mean_spacing, digits=6)}\cos({angle_text(midpoint)})'
                                 rf'}}\approx{number_text(record["ψ理 / (rad/nm)"], digits=3)}\,\mathrm{{rad/nm}}')
        comparisons = []
        for color in COLORS:
            group = frame.loc[(frame[SPECTRAL] == color) & frame[PHI].notna()]
            if set(group[ORDER]) == {1, 2}:
                first, second = (float(group.loc[group[ORDER] == order, PHI].iloc[0]) for order in (1, 2))
                relation = '大于' if second > first else '小于' if second < first else '等于'
                comparisons.append(f'{color}谱线的二级衍射角{relation}一级')
        if comparisons:
            st.write('实测结果：' + '；'.join(comparisons) + '。')
        st.write('由理论公式可知：同级光谱中，长波长的衍射角更大；级次越高，角色散率越大。'
                 '小角度时色散近似均匀，不同级次的光谱可能重叠。')

        st.markdown('**3. 计算分辨本领**')
        st.latex(r'R=\frac{\lambda}{\Delta\lambda}=kN,\qquad N=\frac{l}{\overline d}')
        if math.isfinite(self.slit_count):
            st.latex(rf'l={self.length_mm:g}\,\mathrm{{mm}}={self.length_mm:g}\times10^6\,\mathrm{{nm}}')
            st.latex(rf'N=\frac{{{self.length_mm:g}\times10^6}}{{{number_text(self.mean_spacing, digits=6)}}}'
                     rf'\approx{number_text(self.slit_count)}')
            for order in (1, 2):
                st.latex(rf'R_{{k={order}}}={order}\times{number_text(self.slit_count, digits=6)}'
                         rf'\approx{number_text(order * self.slit_count)}')
        else:
            st.write('填写表头 l 并算出光栅常数后，计算总缝数 N 及一、二级的分辨本领。')

        st.markdown('**思考题**')
        questions = [
            ('当狭缝太宽或太窄时，分别会出现什么现象？',
             '太宽会使谱线变宽、相邻谱线难以分辨；太窄会使光强减弱，谱线暗淡、难以观测。'),
            ('比较光栅光谱与棱镜光谱的异同。',
             '两者都能分光；光栅靠衍射，红光偏转更大且有多级光谱；棱镜靠折射，通常紫光偏转更大。'),
            ('怎样利用光栅常数已知的光栅测量光源的波长？',
             r'使光垂直入射光栅，测量已知级次 $k$ 的衍射角 $\varphi$，由 $\lambda=d\sin\varphi/k$ 求波长。'),
        ]
        for index, (question, answer) in enumerate(questions, 1):
            st.write(f'（{index}）{question}')
            st.markdown(f'答：{answer}')

    def build_plot(self):
        frame = self.final_df[self.input_key]
        available = {font.name for font in fm.fontManager.ttflist}
        font = next((name for name in ('Noto Sans CJK SC', 'Source Han Sans SC', 'SimHei',
                                      'Microsoft YaHei', 'PingFang SC', 'Heiti SC',
                                      'Arial Unicode MS') if name in available), None)
        with mpl.rc_context({
            'font.family': font or 'DejaVu Sans', 'font.size': 10,
            'axes.unicode_minus': False, 'pdf.fonttype': 42, 'svg.fonttype': 'none',
        }):
            # Streamlit 在工作线程中执行；直接用 Agg 画布，不创建桌面 GUI 窗口。
            fig = Figure(figsize=(7.2, 4.8), dpi=100, layout='constrained')
            FigureCanvasAgg(fig)
            ax = fig.subplots()
            for order, color, marker, line in [(1, '#0072B2', 'o', '-'), (2, '#D55E00', 's', '--')]:
                group = frame.loc[frame[ORDER] == order]
                # 不跨过缺失值连线，也不由理论值补造测量点。
                ax.plot(group[WAVE], group[PHI], color=color, marker=marker, linestyle=line,
                        linewidth=1.5, markersize=4.5, label=f'k = {order}')
            ax.set_title('衍射光栅的色散曲线' if font else 'Diffraction grating dispersion curves', pad=32)
            ax.set_xlabel(r'波长 $\lambda$ / nm' if font else r'Wavelength $\lambda$ / nm')
            ax.set_ylabel(r'衍射角 $\varphi$ / °' if font else r'Diffraction angle $\varphi$ / °')
            ax.legend(loc='lower center', bbox_to_anchor=(0.5, 1.01), ncol=2, frameon=False)
            ax.grid(alpha=0.25)
            ax.margins(x=0.06, y=0.10)
            ax.spines[['top', 'right']].set_visible(False)
        return fig

    def plot(self):
        frame = self.final_df[self.input_key]
        if not frame[PHI].notna().any():
            st.info('填写非零级谱线的角位置后，显示两条色散曲线。')
            return
        fig = self.build_plot()
        try:
            st.pyplot(fig, width='stretch')
            st.caption('圆点实线为一级，方点虚线为二级；标记为测量点，缺失记录处断开。')
            for extension, mime in [('png', 'image/png'), ('svg', 'image/svg+xml')]:
                buffer = io.BytesIO()
                fig.savefig(buffer, format=extension, dpi=300)
                st.download_button(
                    f'下载色散曲线 {extension.upper()}', buffer.getvalue(),
                    file_name=f'衍射光栅_色散曲线.{extension}', mime=mime,
                    key=f'{self.experiment_id}_plot_download_{extension}',
                )
        finally:
            fig.clear()
