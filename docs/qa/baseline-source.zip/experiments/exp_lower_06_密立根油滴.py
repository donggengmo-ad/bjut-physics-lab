"""下册实验六：密立根油滴实验。"""

import hashlib
import math
from decimal import Decimal

import numpy as np
import pandas as pd
import streamlit as st


MEASUREMENT = '测量量'
DROPS = ('油滴一', '油滴二', '油滴三')
TIME_ROWS = tuple(f't_g{subscript} / s' for subscript in '₁₂₃₄₅')
STANDARD_E = 1.602e-19

# 实验参数（书中 20 ℃ 条件）
RHO = 981.0          # kg / m^3
G = 9.8017           # m / s^2
ETA = 1.83e-5        # kg / (m·s)
B = 8.23e-3          # Pa·m
P = 101_324.7        # Pa
L = 1.5e-3           # m
D = 5e-3             # m

CHARGE_COEFFICIENT = 18 * math.pi / math.sqrt(2 * RHO * G) * (ETA * L) ** 1.5 * D
CORRECTION_COEFFICIENT = B / P * math.sqrt(2 * RHO * G / (9 * ETA * L))


def calculate_drop(voltage, times):
    """按书中公式计算一个油滴；没有完整必要数据时返回空结果。"""
    numeric_times = pd.to_numeric(pd.Series(times), errors='raise').dropna().to_numpy(dtype=float)
    if len(numeric_times) and (not np.isfinite(numeric_times).all() or (numeric_times <= 0).any()):
        raise ValueError('下落时间必须为正的有限数值。')
    if pd.notna(voltage):
        voltage = float(voltage)
        if not math.isfinite(voltage) or voltage <= 0:
            raise ValueError('平衡电压必须为正的有限数值。')

    result = dict(mean_time=math.nan, radius=math.nan, charge=math.nan,
                  n_calculated=math.nan, n_integer=math.nan,
                  measured_e=math.nan, relative_error=math.nan)
    if not len(numeric_times):
        return result

    mean_time = float(numeric_times.mean())
    result['mean_time'] = mean_time
    result['radius'] = math.sqrt(9 * ETA * L / (2 * RHO * G * mean_time))
    if pd.isna(voltage):
        return result

    charge = CHARGE_COEFFICIENT / (
        (mean_time * (1 + CORRECTION_COEFFICIENT * math.sqrt(mean_time))) ** 1.5
        * voltage
    )
    n_calculated = charge / STANDARD_E
    n_integer = math.floor(n_calculated + 0.5)
    result.update(charge=charge, n_calculated=n_calculated, n_integer=n_integer)
    if n_integer > 0:
        measured_e = charge / n_integer
        result['measured_e'] = measured_e
        result['relative_error'] = abs(measured_e - STANDARD_E) / STANDARD_E * 100
    return result


def display_number(value, digits=3):
    # # 保留有效末尾零，例如 1.00，而不是 1。
    return f'{value:#.{digits}g}' if math.isfinite(value) else '未填写或无法计算'


def latex_number(value, digits=3):
    """把数值的科学计数法转换为可渲染的 LaTeX。"""
    text = display_number(value, digits)
    if 'e' in text:
        mantissa, exponent = text.split('e')
        return rf'{mantissa}\times10^{{{int(exponent)}}}'
    return text


def time_decimal_places(times):
    """按已有记录中最粗的小数精度显示平均值，不推定仪器分辨率。"""
    places = [max(0, -Decimal(str(value)).as_tuple().exponent)
              for value in times if pd.notna(value) and math.isfinite(float(value))]
    return min(places) if places else 0


class Experiment:
    volume = '下册'
    number = 6
    experiment_id = 'lower_06_millikan_oil_drop'

    def __init__(self):
        self.name = '实验六：密立根油滴实验'
        self.description = r"""
##### 数据说明
- 表 6-1 记录三个油滴各自的平衡电压 $U_i$，以及每个油滴 5 次通过 $l=1.5\,\mathrm{mm}$ 距离的下落时间 $t_{g_i}$。
- 实验参数：$\rho=981\,\mathrm{kg/m^3}$，$g=9.8017\,\mathrm{m/s^2}$，$\eta=1.83\times10^{-5}\,\mathrm{kg/(m\cdot s)}$，$b=8.23\times10^{-3}\,\mathrm{Pa\cdot m}$，$p=101324.7\,\mathrm{Pa}$，$d=5\,\mathrm{mm}$。
- “倒过来验证”采用公认电子电荷 $e_{\text{标}}=1.602\times10^{-19}\,\mathrm C$。
- 注意测量结果及其不确定度的有效位数。
"""
        rows = ['U / V', *TIME_ROWS]
        self.input_key = '表 6-1：密立根油滴法的实验数据记录'
        self.initial_df = {
            self.input_key: pd.DataFrame({
                MEASUREMENT: rows,
                '油滴一': [102, 30.9, 29.4, 29.47, 29.09, 28.73],
                '油滴二': [290, 11.18, 11.19, 11.03, 11.28, 11.05],
                '油滴三': [160, 11.71, 11.69, 11.93, 11.72, 11.75],
            })
        }
        self.static_col = {self.input_key: [MEASUREMENT]}
        self.final_df = {}
        self.results = {}
        self.automatic_means = {}
        self.average_overrides = {drop: None for drop in DROPS}
        self.editor_source = self.initial_df[self.input_key].copy()
        self.editor_version = 0
        self.upload_digest = None

    def set_initial_df(self, frame, key):
        if key != self.input_key:
            raise KeyError(key)
        expected_columns = [MEASUREMENT, *DROPS]
        expected_rows = ['U / V', *TIME_ROWS]
        if list(frame.columns) != expected_columns:
            raise ValueError(f'CSV 列名及顺序必须为：{", ".join(expected_columns)}')
        if list(frame[MEASUREMENT]) != expected_rows:
            raise ValueError('CSV 必须依次包含电压和 5 次下落时间。')
        values = frame[list(DROPS)].apply(pd.to_numeric, errors='raise')
        present = values.to_numpy(dtype=float)
        present = present[~np.isnan(present)]
        if not np.isfinite(present).all() or (present <= 0).any():
            raise ValueError('电压和下落时间必须为正的有限数值。')
        self.initial_df[key] = frame.copy()

    def render_inputs(self):
        if not hasattr(self, 'average_overrides'):
            self.average_overrides = {drop: None for drop in DROPS}
        key = self.input_key
        uploaded = st.file_uploader(
            '上传 CSV 文件', type='csv',
            key=f'{self.experiment_id}_upload',
            help='列名、单位及格式须与下载的输入表一致。',
        )
        if uploaded is None:
            self.upload_digest = None
        else:
            digest = hashlib.sha256(uploaded.getvalue()).hexdigest()
            if digest != self.upload_digest:
                try:
                    imported = pd.read_csv(uploaded).drop(columns='Unnamed: 0', errors='ignore')
                    self.set_initial_df(imported, key)
                    self.editor_source = self.initial_df[key].copy()
                    self.editor_version += 1
                    self.upload_digest = digest
                except (ValueError, KeyError, pd.errors.ParserError) as error:
                    st.error(f'CSV 导入失败：{error}')

        editor_key = f'{self.experiment_id}_editor_{self.editor_version}'
        if editor_key not in st.session_state:
            self.editor_source = self.initial_df[key].copy()
        edited = st.data_editor(
            self.editor_source,
            hide_index=True,
            disabled=[MEASUREMENT],
            key=editor_key,
            column_config={drop: st.column_config.NumberColumn(min_value=0.0) for drop in DROPS},
        )
        try:
            self.set_initial_df(edited, key)
        except ValueError as error:
            st.error(str(error))

        st.markdown('**平均下降时间**')
        st.caption('可直接填写平均下降时间；留空时由上面 5 次下落时间自动计算。')
        source = self.initial_df[key].set_index(MEASUREMENT)
        for drop in DROPS:
            state_key = f'{self.experiment_id}_mean_override_{drop}'
            if state_key not in st.session_state:
                st.session_state[state_key] = self.average_overrides.get(drop)
            raw_times = pd.to_numeric(source.loc[list(TIME_ROWS), drop], errors='coerce').dropna()
            automatic = float(raw_times.mean()) if len(raw_times) else math.nan
            self.average_overrides[drop] = st.number_input(
                f'{drop}平均下降时间 / s', min_value=1e-9, value=None,
                format='%g', placeholder='留空时自动计算', key=state_key,
            )
            if math.isfinite(automatic):
                st.caption(f'{drop}当前自动计算值：{self.time_text(drop, automatic, automatic=True)} s')
        st.download_button(
            '下载 CSV 文件', self.initial_df[key].to_csv(index=False),
            file_name='下册_实验六_密立根油滴_表6-1.csv', mime='text/csv',
            key=f'{self.experiment_id}_download',
        )

    def fill_data(self):
        if not hasattr(self, 'average_overrides'):
            self.average_overrides = {drop: None for drop in DROPS}
        source = self.initial_df[self.input_key].set_index(MEASUREMENT)
        self.results = {}
        self.automatic_means = {}
        table_61 = self.initial_df[self.input_key].copy()
        average_row = {MEASUREMENT: '平均下降时间 / s'}
        table_62_rows = []

        for drop in DROPS:
            voltage = source.loc['U / V', drop]
            times = source.loc[list(TIME_ROWS), drop]
            automatic_result = calculate_drop(voltage, times)
            self.automatic_means[drop] = automatic_result['mean_time']
            override = self.average_overrides.get(drop)
            if override is not None:
                if not math.isfinite(float(override)) or float(override) <= 0:
                    raise ValueError('直接填写的平均下降时间必须为正的有限数值。')
                result = calculate_drop(voltage, [float(override)])
            else:
                result = automatic_result
            self.results[drop] = result
            average_row[drop] = result['mean_time']
            table_62_rows.append({
                '油滴': drop[-1],
                'Uᵢ / V': voltage,
                '平均 t̄gᵢ / s': result['mean_time'],
                'qᵢ / C': result['charge'],
                'n计算ᵢ = qᵢ/e标': result['n_calculated'],
                'n整数ᵢ': result['n_integer'],
                'e测ᵢ = qᵢ/n整数ᵢ / C': result['measured_e'],
            })

        table_61 = pd.concat([table_61, pd.DataFrame([average_row])], ignore_index=True)
        self.final_df = {
            '表 6-1：密立根油滴法的实验数据记录': table_61,
            '表 6-2：“倒过来验证”电荷量数据': pd.DataFrame(table_62_rows),
        }

    def time_text(self, drop, value, automatic=False):
        source = self.initial_df[self.input_key].set_index(MEASUREMENT)
        override = self.average_overrides.get(drop)
        times = [override] if override is not None and not automatic else source.loc[list(TIME_ROWS), drop]
        return f'{value:.{time_decimal_places(times)}f}'

    def render_results(self):
        """小表格使用原生 Markdown 表格渲染表头和单元格公式。"""
        headers = {
            'Uᵢ / V': r'$U_i/\mathrm{V}$',
            '平均 t̄gᵢ / s': r'$\overline{t}_{g_i}/\mathrm{s}$',
            'qᵢ / C': r'$q_i/\mathrm{C}$',
            'n计算ᵢ = qᵢ/e标': r'$n_{\text{计算},i}=q_i/e_{\text{标}}$',
            'n整数ᵢ': r'$n_{\text{整数},i}$',
            'e测ᵢ = qᵢ/n整数ᵢ / C': r'$e_{\text{测},i}=q_i/n_{\text{整数},i}$，$\mathrm{C}$',
        }
        row_labels = {
            'U / V': r'$U/\mathrm{V}$',
            **{label: rf'$t_{{g_{index}}}/\mathrm{{s}}$'
               for index, label in enumerate(TIME_ROWS, 1)},
            '平均下降时间 / s': r'平均下降时间 $\overline{t}_g/\mathrm{s}$',
        }
        for index, (name, frame) in enumerate(self.final_df.items(), 1):
            display = frame.copy()
            for column in frame.columns:
                if pd.api.types.is_numeric_dtype(frame[column]):
                    cells = []
                    for row, value in enumerate(frame[column]):
                        if pd.isna(value):
                            cells.append('—')
                            continue
                        if MEASUREMENT in frame:
                            label = frame.iloc[row][MEASUREMENT]
                            if label == '平均下降时间 / s':
                                text = self.time_text(column, value)
                            elif label == 'U / V':
                                text = f'{value:g}'
                            else:
                                text = str(value)
                        elif column == '平均 t̄gᵢ / s':
                            text = self.time_text(DROPS[row], value)
                        elif column == 'Uᵢ / V':
                            text = f'{value:g}'
                        elif column == 'n整数ᵢ':
                            text = str(int(value))
                        else:
                            text = latex_number(value)
                        cells.append(f'${text}$')
                    display[column] = cells
            if MEASUREMENT in display:
                display[MEASUREMENT] = display[MEASUREMENT].replace(row_labels)
            st.markdown(f'**{name}**')
            st.table(display.rename(columns=headers), hide_index=True)
            st.download_button(
                '下载结果 CSV', frame.to_csv(index=False),
                file_name=f'下册_实验六_密立根油滴_表6-{index}.csv', mime='text/csv',
                key=f'{self.experiment_id}_result_download_{index}',
            )

    def calculate(self):
        st.markdown('**1. 计算三个油滴下落时间的平均值**')
        st.latex(r'\overline{t}_{g_i}=\frac{1}{n}\sum_{j=1}^{n}t_{g_{ij}}')
        source = self.initial_df[self.input_key].set_index(MEASUREMENT)
        for index, drop in enumerate(DROPS, 1):
            values = pd.to_numeric(
                source.loc[list(TIME_ROWS), drop], errors='coerce'
            ).dropna().tolist()
            override = self.average_overrides.get(drop)
            if override is not None:
                st.latex(rf'\overline{{t}}_{{g_{index}}}={self.time_text(drop, float(override))}\,\mathrm{{s}}\quad\text{{（直接修改值）}}')
                if values:
                    st.caption(f'{drop}由 5 次下落时间自动计算的平均值为 {self.time_text(drop, self.automatic_means[drop], automatic=True)} s。')
            elif values:
                terms = '+'.join(str(value) for value in values)
                st.latex(rf'\overline{{t}}_{{g_{index}}}=\frac{{{terms}}}{{{len(values)}}}\approx{self.time_text(drop, self.results[drop]["mean_time"])}\,\mathrm{{s}}')
            else:
                st.write(f'{drop}：下落时间未填写。')

        st.markdown('**2. 计算三个油滴的电荷量**')
        st.caption('代入过程保留保护位，等式末端与结果表按有效位数显示。')
        st.latex(r'a_i=\sqrt{\frac{9\eta l}{2\rho g\overline{t}_{g_i}}}')
        st.latex(r'q_i=\frac{18\pi}{\sqrt{2\rho g}}\left[\frac{\eta l}{\overline{t}_{g_i}\left(1+\frac{b}{pa_i}\right)}\right]^{\frac{3}{2}}\frac{d}{U_i}')
        st.write('代入本实验参数后：')
        st.latex(r'q_i=\frac{9.27\times10^{-15}}{\left[\overline{t}_{g_i}\left(1+0.0226\sqrt{\overline{t}_{g_i}}\right)\right]^{3/2}U_i}')
        for index, drop in enumerate(DROPS, 1):
            result = self.results[drop]
            voltage = source.loc['U / V', drop]
            if math.isfinite(result['charge']):
                # 代入过程保留保护位，结果表及等式末端按有效位数显示。
                t = f'{result["mean_time"]:g}'
                st.latex(rf'a_{index}=\sqrt{{\frac{{9\times1.83\times10^{{-5}}\times1.5\times10^{{-3}}}}{{2\times981\times9.8017\times{t}}}}}\approx{latex_number(result["radius"])}\,\mathrm{{m}}')
                st.latex(rf'q_{index}=\frac{{9.27\times10^{{-15}}}}{{\left[{t}\left(1+0.0226\sqrt{{{t}}}\right)\right]^{{3/2}}\times{float(voltage):g}}}\approx{latex_number(result["charge"])}\,\mathrm{{C}}')
            elif math.isfinite(result['mean_time']):
                st.write(f'{drop}：平均下落时间为 {self.time_text(drop, result["mean_time"])} s，平衡电压未填写，暂不能计算电荷量。')
            else:
                st.write(f'{drop}：暂不能计算电荷量。')

        st.markdown('**3. 用“倒过来验证”的方法处理电荷量数据（结果见表 6-2）**')
        st.latex(r'n_{\text{计算},i}=\frac{q_i}{e_{\text{标}}},\qquad e_{\text{测},i}=\frac{q_i}{n_{\text{整数},i}}')
        for index, drop in enumerate(DROPS, 1):
            result = self.results[drop]
            if math.isfinite(result['measured_e']):
                st.latex(rf'n_{{\text{{计算}},{index}}}=\frac{{{latex_number(result["charge"], digits=6)}}}{{1.602\times10^{{-19}}}}\approx{latex_number(result["n_calculated"])}\approx {int(result["n_integer"])}')
                st.latex(rf'e_{{\text{{测}},{index}}}=\frac{{{latex_number(result["charge"], digits=6)}}}{{{int(result["n_integer"])}}}\approx{latex_number(result["measured_e"])}\,\mathrm{{C}}')
            else:
                st.write(f'{drop}：电荷量未算出，暂不能进行“倒过来验证”。')

        st.markdown('**4. 计算实验值与公认值的相对误差**')
        st.latex(r'E_r=\frac{\left|e_{\text{测}}-e_{\text{标}}\right|}{e_{\text{标}}}\times100\%')
        for index, drop in enumerate(DROPS, 1):
            result = self.results[drop]
            if math.isfinite(result['relative_error']):
                st.latex(rf'E_{{r,{index}}}=\frac{{\left|{latex_number(result["measured_e"], digits=6)}-1.602\times10^{{-19}}\right|}}{{1.602\times10^{{-19}}}}\times100\%\approx{latex_number(result["relative_error"], digits=2)}\%')
            else:
                st.write(f'{drop}：暂不能计算相对误差。')

        st.markdown('**思考题**')
        questions = [
            ('若平行极板不水平，对测量结果有何影响？',
             '电场偏离竖直方向，油滴发生横向漂移，难以静止，导致平衡电压测量产生系统误差。'),
            ('如何选择合适的油滴进行测量？',
             '选择清晰明亮、大小适中、下降缓慢稳定且能在适中电压下平衡的油滴，避免布朗运动明显的油滴。'),
            ('实验时怎样才能保证油滴做匀速运动？',
             '撤去电场后，待油滴达到终端速度再计时，并避免气流和振动干扰。'),
            ('为什么在实验过程中会出现油滴漂移现象？',
             '主要由空气对流、布朗运动及极板倾斜产生的水平电场分量引起。'),
        ]
        for index, (question, answer) in enumerate(questions, 1):
            st.write(f'（{index}）{question}')
            st.write(f'答：{answer}')

        st.markdown('**分析与讨论**')
        st.write('可以从实验结果、实验背景、实验原理、实验仪器、实验方法、实验应用等方面进行分析与拓展讨论。')

    def plot(self):
        raise NotImplementedError('本实验无需绘图。')
