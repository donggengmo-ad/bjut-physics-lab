import io
import math
import unittest

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from experiments.exp_lower_04_衍射光栅 import (
    ANGLES, ORDER, PHI, PHI_I, PHI_II, SPACING, WAVE,
    Experiment, angle_text, diffraction_angle, parse_angle,
)


def minute_record(degrees):
    degrees, minutes = divmod(round(degrees * 60) % (360 * 60), 60)
    return f'{degrees}.{minutes:02d}'


def sample_experiment():
    """仅供校验：理想 d=2000 nm 的角位置量化到分，不作为默认实验数据。"""
    experiment = Experiment()
    experiment.length_mm = 12.0
    frame = experiment.initial_df[experiment.input_key].copy()
    for row in range(1, 9):
        phi = math.degrees(math.asin(frame.at[row, ORDER] * frame.at[row, WAVE] / 2000))
        for column, reading in zip(ANGLES, (350 - phi, 170 - phi, 350 + phi, 170 + phi)):
            frame.at[row, column] = minute_record(reading)
    experiment.set_initial_df(frame, experiment.input_key)
    return experiment


class GratingCalculations(unittest.TestCase):
    def test_registration_and_exact_book_rows(self):
        from experiments import get_experiments
        experiment = get_experiments()['lower_04_diffraction_grating']
        self.assertEqual((experiment.volume, experiment.number), ('下册', 4))
        self.assertEqual(experiment.name, '实验四：衍射光栅及其特性')
        frame = experiment.initial_df[experiment.input_key]
        self.assertEqual(len(frame), 9)
        self.assertEqual(frame[WAVE].iloc[1:].tolist(),
                         [435.8, 546.1, 577.0, 579.0] * 2)
        self.assertTrue(frame[list(ANGLES)].isna().all().all())

    def test_degree_minute_parsing_and_validation(self):
        for value in ['30.15', '30:15', '30°15′', '30度15分']:
            self.assertAlmostEqual(parse_angle(value), 30.25)
        self.assertAlmostEqual(parse_angle('30.10'), 30 + 10/60)
        self.assertAlmostEqual(parse_angle(30.1), 30 + 10/60)
        self.assertEqual(parse_angle('360.00'), 0)
        self.assertTrue(math.isnan(parse_angle(None)))
        for value in ['30.60', '-1.00', '361', '30.155', 'inf']:
            with self.assertRaises(ValueError):
                parse_angle(value)

    def test_circular_angle_and_quarter_minute(self):
        self.assertEqual(diffraction_angle(350, 10), 10)
        self.assertEqual(diffraction_angle(170, 190), 10)
        self.assertEqual(diffraction_angle(10, 350), 10)
        self.assertTrue(math.isnan(diffraction_angle(math.nan, 10)))
        self.assertEqual(angle_text(1 + 15/3600), r'1^{\circ}00^{\prime}15^{\prime\prime}')
        self.assertEqual(angle_text(10), r'10^{\circ}00^{\prime}')

    def test_spacing_dispersion_and_resolution_units(self):
        experiment = sample_experiment()
        experiment.fill_data()
        frame = experiment.final_df[experiment.input_key]
        expected_spacings = []
        for row in range(1, 9):
            left_i, left_ii, right_i, right_ii = [
                parse_angle(frame.at[row, column]) for column in ANGLES
            ]
            first = min(abs(right_i-left_i), 360-abs(right_i-left_i))/2
            second = min(abs(right_ii-left_ii), 360-abs(right_ii-left_ii))/2
            phi = (first+second)/2
            self.assertAlmostEqual(frame.at[row, PHI], phi)
            expected_spacings.append(frame.at[row, ORDER]*frame.at[row, WAVE]/math.sin(math.radians(phi)))
        mean = sum(expected_spacings)/8
        self.assertEqual(experiment.spacing_count, 8)
        self.assertAlmostEqual(experiment.mean_spacing, mean)
        self.assertLess(abs(mean/2000-1), 0.001)
        self.assertAlmostEqual(experiment.slit_count, 12*1e6/mean)
        interval = experiment.dispersion.iloc[0]
        phi_a, phi_b = frame.at[1, PHI], frame.at[2, PHI]
        self.assertAlmostEqual(interval['ψ实 / (rad/nm)'],
                               math.radians(phi_b-phi_a)/(546.1-435.8))
        self.assertAlmostEqual(interval['ψ理 / (rad/nm)'],
                               1/(mean*math.cos(math.radians((phi_a+phi_b)/2))))
        self.assertAlmostEqual(interval['k/d̄ / (rad/nm)'], 1/mean)
        self.assertTrue(frame.loc[0, [PHI, SPACING]].isna().all())

    def test_partial_cursor_and_zero_order_do_not_fabricate_results(self):
        experiment = Experiment()
        frame = experiment.initial_df[experiment.input_key].copy()
        frame.loc[0, list(ANGLES)] = ['350.00', '170.00', '10.00', '190.00']
        frame.loc[1, [ANGLES[0], ANGLES[2]]] = ['350.00', '10.00']
        experiment.set_initial_df(frame, experiment.input_key)
        experiment.fill_data()
        result = experiment.final_df[experiment.input_key]
        self.assertEqual(result.at[1, PHI_I], 10)
        self.assertTrue(math.isnan(result.at[1, PHI_II]))
        self.assertTrue(math.isnan(result.at[1, SPACING]))
        self.assertTrue(math.isnan(experiment.mean_spacing))
        self.assertTrue(math.isnan(experiment.slit_count))

    def test_missing_point_leaves_curve_gap_and_no_bridged_slope(self):
        experiment = sample_experiment()
        frame = experiment.initial_df[experiment.input_key].copy()
        frame.loc[2, list(ANGLES)] = None
        experiment.set_initial_df(frame, experiment.input_key)
        experiment.fill_data()
        self.assertEqual(experiment.spacing_count, 7)
        self.assertTrue(experiment.dispersion.iloc[:2]['ψ实 / (rad/nm)'].isna().all())
        self.assertTrue(math.isfinite(experiment.dispersion.iloc[2]['ψ实 / (rad/nm)']))
        fig = experiment.build_plot()
        try:
            self.assertTrue(math.isnan(fig.axes[0].lines[0].get_ydata()[1]))
        finally:
            plt.close(fig)

    def test_csv_preserves_minutes_and_rejects_invalid_record(self):
        experiment = sample_experiment()
        frame = experiment.initial_df[experiment.input_key].copy()
        frame.at[1, ANGLES[0]] = '30.10'
        imported = pd.read_csv(io.StringIO(frame.to_csv(index=False)),
                               dtype={column: 'string' for column in ANGLES})
        experiment.set_initial_df(imported, experiment.input_key)
        self.assertEqual(experiment.initial_df[experiment.input_key].at[1, ANGLES[0]], '30.10')
        for bad_frame in [frame.iloc[:-1], frame.assign(**{WAVE: 500.0})]:
            with self.assertRaises(ValueError):
                experiment.set_initial_df(bad_frame, experiment.input_key)
        frame.at[1, ANGLES[0]] = '20.70'
        with self.assertRaises(ValueError):
            experiment.set_initial_df(frame, experiment.input_key)

    def test_zero_diffraction_angle_and_missing_length(self):
        experiment = sample_experiment()
        experiment.length_mm = None
        frame = experiment.initial_df[experiment.input_key].copy()
        frame.loc[1, list(ANGLES)] = ['10.00', '190.00', '10.00', '190.00']
        experiment.set_initial_df(frame, experiment.input_key)
        experiment.fill_data()
        self.assertTrue(math.isnan(experiment.final_df[experiment.input_key].at[1, SPACING]))
        self.assertTrue(math.isnan(experiment.slit_count))
        self.assertTrue(experiment.input_issues)

    def test_plot_has_two_measured_curves_and_units(self):
        experiment = sample_experiment()
        experiment.fill_data()
        fig = experiment.build_plot()
        try:
            ax = fig.axes[0]
            self.assertEqual(len(ax.lines), 2)
            self.assertEqual(list(ax.lines[0].get_xdata()), [435.8, 546.1, 577.0, 579.0])
            np.testing.assert_allclose(ax.lines[1].get_ydata(),
                                       experiment.final_df[experiment.input_key].loc[5:8, PHI])
            self.assertIn('nm', ax.get_xlabel())
            self.assertIn('°', ax.get_ylabel())
            self.assertNotEqual(ax.lines[0].get_marker(), ax.lines[1].get_marker())
            self.assertNotEqual(ax.lines[0].get_linestyle(), ax.lines[1].get_linestyle())
        finally:
            plt.close(fig)

    def test_actual_app_blank_and_filled_states(self):
        from streamlit.testing.v1 import AppTest
        app = AppTest.from_file('app.py', default_timeout=20)
        app.session_state['select_exp'] = 'lower_04_diffraction_grating'
        app.run()
        self.assertFalse(app.exception)
        self.assertFalse(app.error, [item.value for item in app.error])
        self.assertEqual(len(app.table), 2)
        self.assertIn('577.0', app.table[0].value[r'$\lambda/\mathrm{nm}$'].tolist())
        app.session_state['experiment_lower_04_diffraction_grating'] = sample_experiment()
        # 与真实章节切换一样，控件重新出现时由实验对象恢复编辑源。
        app.session_state['experiment_lower_04_diffraction_grating'].editor_version += 1
        app.run()
        self.assertFalse(app.exception)
        self.assertFalse(app.error, [item.value for item in app.error])
        self.assertTrue(app.table[0].value[r'$d_i/\mathrm{nm}$'].iloc[1] != '—')
        formulas = '\n'.join(item.value for item in app.latex)
        self.assertIn(r'\psi_{\text{实}}', formulas)
        self.assertIn(r'\psi_{\text{理}}', formulas)
        app.number_input(key='lower_04_diffraction_grating_length').set_value(12.0).run()
        self.assertFalse(app.exception)
        self.assertTrue(math.isfinite(
            app.session_state['experiment_lower_04_diffraction_grating'].slit_count))
        self.assertIn('分辨本领', '\n'.join(item.value for item in app.markdown))


if __name__ == '__main__':
    unittest.main()
